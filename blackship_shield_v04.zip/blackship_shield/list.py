"""Blackship Shield process indicators.

Names are review indicators, not proof of malicious activity. No automatic killing.
Add exact executable basenames only; avoid generic system processes.
"""

# Legitimate remote administration / screen-sharing tools can pose a privacy
# risk when running unexpectedly. They are NOT malware by definition.
REMOTE_ACCESS = frozenset({
    'anydesk.exe', 'teamviewer.exe', 'teamviewer_service.exe',
    'rustdesk.exe', 'supremo.exe', 'ultraviewer_desktop.exe',
    'screenconnect.clientservice.exe', 'aeroadmin.exe',
    'ammyy_admin.exe', 'dwagent.exe',
})

# Legitimate capture/streaming tools: review only when unexpected.
SCREEN_CAPTURE = frozenset({
    'obs64.exe', 'obs32.exe', 'sharex.exe', 'bandicam.exe',
    'screenrec.exe', 'camtasia.exe', 'snagitcapture.exe',
})

PROCESS_INDICATORS = {
    'remote-access': REMOTE_ACCESS,
    'screen-capture': SCREEN_CAPTURE,
}

CATEGORY_LABELS = {
    'remote-access': '원격 접속 도구',
    'screen-capture': '화면 캡처·녹화 도구',
}
