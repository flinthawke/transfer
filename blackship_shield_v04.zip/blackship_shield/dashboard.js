'use strict';
const token = new URLSearchParams(location.hash.slice(1)).get('token');
if (token) history.replaceState(null,'',location.pathname);
const el=id=>document.getElementById(id);
const req=async(path,method='GET',body)=>{
 const res=await fetch(path,{method,headers:{'X-Shield-Token':token,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,cache:'no-store'});
 const data=await res.json(); if(!res.ok)throw Error(data.error||`HTTP ${res.status}`);return data;
};
function cell(row,value){const td=document.createElement('td');td.textContent=String(value);row.append(td);return td;}
function renderLogs(events){const body=el('events');body.replaceChildren();for(const e of [...events].reverse()){
 const row=document.createElement('tr');cell(row,e.at);cell(row,e.kind);cell(row,e.detail);body.append(row);
}}
async function poll(){try{const d=await req('/api/state');el('connected').textContent='로컬 엔진 연결됨';el('camera').textContent=d.state.camera;el('screen').textContent=d.state.screen;el('blocks').textContent=d.state.blocks;
 const t=d.uptime;el('uptime').textContent=[Math.floor(t/3600),Math.floor(t/60)%60,t%60].map(x=>String(x).padStart(2,'0')).join(':');renderLogs(d.events);
}catch(e){el('connected').textContent='엔진 연결 끊김';}}
async function refresh(){try{const d=await req('/api/processes');const body=el('processes');body.replaceChildren();for(const p of d.processes){const tr=document.createElement('tr');cell(tr,p.pid);cell(tr,p.name||'?');const td=document.createElement('td');const b=document.createElement('button');b.textContent='종료';b.className='danger';b.onclick=async()=>{if(!confirm(`${p.name} (PID ${p.pid}) 프로세스를 강제 종료하시겠습니까?`))return;try{await req('/api/terminate','POST',{pid:p.pid,created:p.create_time});el('message').textContent=`PID ${p.pid} 종료 요청이 완료되었습니다.`;refresh();}catch(e){el('message').textContent=e.message;}};td.append(b);tr.append(td);body.append(tr);}}catch(e){el('message').textContent=e.message;}}
el('refresh').onclick=refresh;
el('launch').onclick=async()=>{try{const d=await req('/api/browser','POST');el('message').textContent=`격리 브라우저: ${d.result}`;}catch(e){el('message').textContent=e.message;}};
el('end').onclick=async()=>{if(!confirm('격리 브라우저를 닫고 Shield 전용 임시 프로필을 삭제하시겠습니까?'))return;try{const d=await req('/api/end','POST');el('message').textContent=`종료 요청이 완료되었습니다. / 정리: ${d.state.cleanup}`;poll();}catch(e){el('message').textContent=e.message;}};
poll();refresh();setInterval(poll,1000);
