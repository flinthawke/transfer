"""Blackship Shield v0.4 - local-only Windows security dashboard.
Requires Windows, Flask and psutil. No administrator rights assumed.
"""
import atexit
import ctypes
from ctypes import wintypes
from datetime import datetime
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
import winreg
import webbrowser

import psutil
from flask import Flask, jsonify, request, send_from_directory, abort

HERE = Path(__file__).resolve().parent
app = Flask(__name__, static_folder=None)
TOKEN = secrets.token_urlsafe(32)
EVENTS = []
LOCK = threading.RLock()
STOP = threading.Event()
CONSENT = threading.Event()
STARTED = time.time()
STATE = {'camera': 'starting', 'screen': 'starting', 'cleanup': 'session-only', 'blocks': 0}
BASE = r'SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore'
AFFINITY = 0x11


def log(kind, detail):
    with LOCK:
        EVENTS.append({'at': datetime.now().astimezone().isoformat(timespec='seconds'), 'kind': kind, 'detail': detail})
        del EVENTS[:-400]


def consent_entries():
    """Returns (media, encoded app identifier, start, stop) for HKCU ConsentStore.
    Windows may use stop=0 or start>stop while active. This is not a guaranteed PID feed.
    """
    items = {}
    for media in ('webcam', 'microphone'):
        try:
            base = winreg.OpenKey(winreg.HKEY_CURRENT_USER, BASE + '\\' + media)
        except OSError:
            continue
        with base:
            stack = [(base, '')]
            try:
                np = winreg.OpenKey(base, 'NonPackaged')
                stack.append((np, 'NonPackaged/'))
            except OSError:
                pass
            for parent, prefix in stack:
                try:
                    count = winreg.QueryInfoKey(parent)[0]
                except OSError:
                    continue
                for i in range(count):
                    try:
                        name = winreg.EnumKey(parent, i)
                        with winreg.OpenKey(parent, name) as sub:
                            start = int(winreg.QueryValueEx(sub, 'LastUsedTimeStart')[0])
                            stop = int(winreg.QueryValueEx(sub, 'LastUsedTimeStop')[0])
                            items[(media, prefix + name)] = (start, stop)
                    except (OSError, ValueError, TypeError):
                        continue
            if len(stack) > 1:
                stack[1][0].Close()
    return items


def active(record):
    start, stop = record
    return start > 0 and (stop == 0 or start > stop)


def watcher():
    try:
        prev = consent_entries()
        STATE['camera'] = 'watching'
        log('monitor', '카메라/마이크 ConsentStore 감시 시작 (HKCU, 1초 주기)')
    except Exception as exc:
        STATE['camera'] = 'error'
        log('error', f'레지스트리 읽기 실패: {exc}')
        return
    while not STOP.wait(1):
        try:
            now = consent_entries()
            for key, record in now.items():
                old = prev.get(key, (0, 0))
                if active(record) and (not active(old) or record[0] != old[0]):
                    media, identifier = key
                    log('media-alert', f'{media} 사용 기록 감지: {identifier} (PID 검증되지 않아 자동 종료하지 않음)')
            prev = now
        except Exception as exc:
            log('error', f'감시 오류: {exc}')


def session_profile():
    """Isolated Chromium user-data-dir: cleanup never touches shared/default browser data."""
    return Path(tempfile.mkdtemp(prefix='blackship-shield-'))


PROFILE = session_profile()
BROWSER = None


def launch_isolated_browser():
    global BROWSER
    if BROWSER and BROWSER.poll() is None:
        return 'already running'
    paths = [
        Path(os.environ.get('PROGRAMFILES', 'C:/Program Files')) / 'Google/Chrome/Application/chrome.exe',
        Path(os.environ.get('PROGRAMFILES(X86)', 'C:/Program Files (x86)')) / 'Google/Chrome/Application/chrome.exe',
        Path(os.environ.get('LOCALAPPDATA', '')) / 'Google/Chrome/Application/chrome.exe',
        Path(os.environ.get('PROGRAMFILES(X86)', 'C:/Program Files (x86)')) / 'Microsoft/Edge/Application/msedge.exe',
        Path(os.environ.get('PROGRAMFILES', 'C:/Program Files')) / 'Microsoft/Edge/Application/msedge.exe',
    ]
    executable = next((p for p in paths if p.is_file()), None)
    if not executable:
        raise RuntimeError('Chrome 또는 Edge 실행 파일을 찾지 못했습니다.')
    BROWSER = subprocess.Popen([str(executable), f'--user-data-dir={PROFILE}', '--no-first-run', '--new-window', 'about:blank'])
    log('browser', f'격리된 브라우저 실행: {executable.name}, PID={BROWSER.pid}')
    return f'PID {BROWSER.pid}'


def cleanup():
    global BROWSER
    if BROWSER is not None and BROWSER.poll() is None:
        # Only processes with this exact temporary user-data-dir are candidates.
        target = str(PROFILE).lower()
        matches = []
        for p in psutil.process_iter(['pid', 'cmdline']):
            try:
                cmd = p.info['cmdline'] or []
                if any(arg.lower().startswith('--user-data-dir=') and arg.split('=', 1)[1].strip('"').lower() == target for arg in cmd):
                    matches.append(p)
            except (psutil.Error, OSError):
                continue
        for p in matches:
            try:
                p.terminate()
            except (psutil.Error, OSError):
                pass
        psutil.wait_procs(matches, timeout=3)
        for p in matches:
            if p.is_running():
                try:
                    p.kill()
                except (psutil.Error, OSError):
                    pass
        BROWSER = None
    # Do not remove an active profile: Windows file locks may prevent deletion.
    try:
        shutil.rmtree(PROFILE)
        STATE['cleanup'] = 'complete'
        log('cleanup', 'Shield 전용 임시 브라우저 프로필 삭제 완료')
    except OSError as exc:
        STATE['cleanup'] = 'partial'
        log('error', f'임시 프로필 일부 삭제 실패: {exc}')


def protect_window(hwnd):
    """Only a window owned by this process is eligible for display affinity."""
    pid = wintypes.DWORD()
    ctypes.windll.user32.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(pid))
    if pid.value != os.getpid():
        raise ValueError('다른 프로세스의 창에는 SetWindowDisplayAffinity를 적용할 수 없습니다.')
    if not ctypes.windll.user32.SetWindowDisplayAffinity(wintypes.HWND(hwnd), AFFINITY):
        raise ctypes.WinError()


def screen_guard():
    """Own-process native shield window; never claims to protect Chrome/Edge."""
    import tkinter as tk
    try:
        root = tk.Tk()
        root.title('Blackship Shield - Protected Window')
        root.geometry('470x150+120+120')
        root.configure(bg='#0c1423')
        label = tk.Label(root, text='BLACKSHIP SHIELD\n이 창은 지원되는 화면 캡처에서 제외됩니다', fg='#9ce6ec', bg='#0c1423', font=('Segoe UI', 13))
        label.pack(expand=True)
        root.update_idletasks()
        protect_window(root.winfo_id())
        STATE['screen'] = 'own-window-protected'
        log('screen', 'Shield 네이티브 창 WDA_EXCLUDEFROMCAPTURE 적용 성공')
        def poll():
            if STOP.is_set():
                root.destroy()
            else:
                root.after(300, poll)
        root.after(300, poll)
        root.mainloop()
    except Exception as exc:
        STATE['screen'] = 'unsupported'
        log('error', f'화면 캡처 제외 적용 실패: {exc}')


def auth():
    if request.headers.get('X-Shield-Token') != TOKEN:
        abort(403)
    if request.remote_addr not in ('127.0.0.1', '::1'):
        abort(403)


@app.after_request
def headers(resp):
    resp.headers['Cache-Control'] = 'no-store'
    resp.headers['X-Content-Type-Options'] = 'nosniff'
    resp.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'"
    return resp


@app.get('/')
def index():
    return send_from_directory(HERE, 'dashboard.html')


@app.get('/dashboard.js')
def js():
    return send_from_directory(HERE, 'dashboard.js')


@app.get('/api/state')
def state():
    auth()
    with LOCK:
        return jsonify(state=STATE.copy(), events=EVENTS[-120:], uptime=int(time.time()-STARTED))


@app.post('/api/browser')
def browser():
    auth()
    try:
        return jsonify(ok=True, result=launch_isolated_browser())
    except Exception as exc:
        log('error', str(exc))
        return jsonify(ok=False, error=str(exc)), 400


@app.post('/api/end')
def end():
    auth()
    STOP.set()
    cleanup()
    return jsonify(ok=True, state=STATE.copy())


@app.post('/api/terminate')
def terminate():
    """Explicit, verified PID + creation-time confirmation; no blind registry-to-PID kill."""
    auth()
    data = request.get_json(silent=True) or {}
    try:
        pid = int(data['pid'])
        created = float(data['created'])
        proc = psutil.Process(pid)
        if abs(proc.create_time() - created) > .05:
            raise ValueError('프로세스 식별 정보가 바뀌었어.')
        if pid == os.getpid() or pid in (0, 4):
            raise ValueError('시스템 또는 Shield 프로세스 종료 불가')
        name = proc.name()
        proc.kill()
        STATE['blocks'] += 1
        log('blocked', f'사용자 승인 종료: {name}, PID={pid}')
        return jsonify(ok=True)
    except (KeyError, ValueError, psutil.Error, OSError) as exc:
        return jsonify(ok=False, error=str(exc)), 400


@app.get('/api/processes')
def processes():
    auth()
    items = []
    for proc in psutil.process_iter(['pid', 'name', 'create_time']):
        try:
            items.append(proc.info)
        except psutil.Error:
            continue
    return jsonify(processes=items[:800])


def shutdown():
    STOP.set()
    if PROFILE.exists():
        cleanup()


if __name__ == '__main__':
    if os.name != 'nt':
        raise SystemExit('이 빌드는 Windows API 전용이야.')
    atexit.register(shutdown)
    threading.Thread(target=watcher, daemon=True).start()
    threading.Thread(target=screen_guard, daemon=True).start()
    from werkzeug.serving import make_server
    server = make_server('127.0.0.1', 0, app, threaded=True)
    port = server.server_port
    print(f'Blackship Shield local dashboard: http://127.0.0.1:{port}/#token={TOKEN}')
    webbrowser.open(f'http://127.0.0.1:{port}/#token={TOKEN}')
    try:
        server.serve_forever()
    finally:
        shutdown()
