"""Blackship Shield v0.4 - local-only Windows security dashboard.
Requires Windows, Flask and psutil. No administrator rights assumed.
"""
import atexit
import urllib.request
import urllib.error
import ctypes
from ctypes import wintypes
from datetime import datetime
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
import winreg
import webbrowser

import psutil
from flask import Flask, jsonify, request, send_from_directory, abort

HERE = Path(__file__).resolve().parent
app = Flask(__name__, static_folder=None)
TOKEN = secrets.token_urlsafe(32)
EVENTS = []
LOCK = threading.RLock()
STOP = threading.Event()
STARTED = time.time()
STATE = {'camera': 'starting', 'screen': 'starting', 'cleanup': 'session-only', 'blocks': 0}
BASE = r'SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore'
AFFINITY = 0x11


def log(kind, detail):
    with LOCK:
        EVENTS.append({'at': datetime.now().astimezone().isoformat(timespec='seconds'), 'kind': kind, 'detail': detail})
        del EVENTS[:-400]


def consent_entries():
    """Returns (media, encoded app identifier, start, stop) for HKCU ConsentStore.
    Windows may use stop=0 or start>stop while active. This is not a guaranteed PID feed.
    """
    items = {}
    for media in ('webcam', 'microphone'):
        try:
            base = winreg.OpenKey(winreg.HKEY_CURRENT_USER, BASE + '\\' + media)
        except OSError:
            continue
        with base:
            stack = [(base, '')]
            try:
                np = winreg.OpenKey(base, 'NonPackaged')
                stack.append((np, 'NonPackaged/'))
            except OSError:
                pass
            for parent, prefix in stack:
                try:
                    count = winreg.QueryInfoKey(parent)[0]
                except OSError:
                    continue
                for i in range(count):
                    try:
                        name = winreg.EnumKey(parent, i)
                        with winreg.OpenKey(parent, name) as sub:
                            start = int(winreg.QueryValueEx(sub, 'LastUsedTimeStart')[0])
                            stop = int(winreg.QueryValueEx(sub, 'LastUsedTimeStop')[0])
                            items[(media, prefix + name)] = (start, stop)
                    except (OSError, ValueError, TypeError):
                        continue
            if len(stack) > 1:
                stack[1][0].Close()
    return items


def active(record):
    start, stop = record
    return start > 0 and (stop == 0 or start > stop)


def watcher():
    try:
        prev = consent_entries()
        STATE['camera'] = 'watching'
        log('monitor', '카메라/마이크 ConsentStore 감시 시작 (HKCU, 1초 주기)')
    except Exception as exc:
        STATE['camera'] = 'error'
        log('error', f'레지스트리 읽기 실패: {exc}')
        return
    while not STOP.wait(1):
        try:
            now = consent_entries()
            for key, record in now.items():
                old = prev.get(key, (0, 0))
                if active(record) and (not active(old) or record[0] != old[0]):
                    media, identifier = key
                    log('media-alert', f'{media} 사용 기록 감지: {identifier} (PID 검증되지 않아 자동 종료하지 않음)')
            prev = now
        except Exception as exc:
            log('error', f'감시 오류: {exc}')


def session_profile():
    """Isolated Chromium user-data-dir: cleanup never touches shared/default browser data."""
    return Path(tempfile.mkdtemp(prefix='blackship-shield-'))


PROFILE = None
BROWSER = None
BROWSER_LOCK = threading.RLock()
BROWSER_JOB = None
JOB_ASSIGNED = False


def create_browser_job():
    """Windows Job Object: close handle terminates assigned browser process tree.

    Assignment may fail when a browser is already inside an incompatible job.
    In that case, existing profile-based cleanup remains the fallback.
    """
    class IO_COUNTERS(ctypes.Structure):
        _fields_ = [(name, ctypes.c_ulonglong) for name in
                    ('ReadOperationCount', 'WriteOperationCount', 'OtherOperationCount',
                     'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount')]

    class BASIC_LIMITS(ctypes.Structure):
        _fields_ = [('PerProcessUserTimeLimit', ctypes.c_longlong),
                    ('PerJobUserTimeLimit', ctypes.c_longlong),
                    ('LimitFlags', wintypes.DWORD),
                    ('MinimumWorkingSetSize', ctypes.c_size_t),
                    ('MaximumWorkingSetSize', ctypes.c_size_t),
                    ('ActiveProcessLimit', wintypes.DWORD),
                    ('Affinity', ctypes.c_size_t),
                    ('PriorityClass', wintypes.DWORD),
                    ('SchedulingClass', wintypes.DWORD)]

    class EXTENDED_LIMITS(ctypes.Structure):
        _fields_ = [('BasicLimitInformation', BASIC_LIMITS),
                    ('IoInfo', IO_COUNTERS),
                    ('ProcessMemoryLimit', ctypes.c_size_t),
                    ('JobMemoryLimit', ctypes.c_size_t),
                    ('PeakProcessMemoryUsed', ctypes.c_size_t),
                    ('PeakJobMemoryUsed', ctypes.c_size_t)]

    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
    kernel.CreateJobObjectW.restype = wintypes.HANDLE
    kernel.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    kernel.SetInformationJobObject.restype = wintypes.BOOL
    job = kernel.CreateJobObjectW(None, None)
    if not job:
        raise ctypes.WinError(ctypes.get_last_error())
    limits = EXTENDED_LIMITS()
    limits.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    if not kernel.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
        error = ctypes.get_last_error()
        kernel.CloseHandle(job)
        raise ctypes.WinError(error)
    return job


def assign_browser_job(job, pid):
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    kernel.AssignProcessToJobObject.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.OpenProcess(0x0100 | 0x0001, False, pid)  # SET_QUOTA | TERMINATE
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        if not kernel.AssignProcessToJobObject(job, handle):
            raise ctypes.WinError(ctypes.get_last_error())
    finally:
        kernel.CloseHandle(handle)


def close_browser_job():
    global BROWSER_JOB, JOB_ASSIGNED
    if BROWSER_JOB is not None:
        ctypes.windll.kernel32.CloseHandle(BROWSER_JOB)
        BROWSER_JOB = None
    JOB_ASSIGNED = False
    STATE['browser_job'] = 'closed'



# Chromium's OS sandbox is enabled by default. Never add --no-sandbox,
# --disable-gpu-sandbox, or --disable-site-isolation-trials.
# --js-flags=--jitless disables V8 JIT executable-code generation (a memory
# exploitation hardening tradeoff); some WebAssembly sites may not work.
CHROMIUM_HARDENING_FLAGS = (
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-extensions',
    '--incognito',
    '--site-per-process',
    '--js-flags=--jitless',
    '--new-window',
)


def hardened_browser_command(executable, profile):
    """Keep all flags as separate argv items; never invoke a shell."""
    return [str(executable), f'--user-data-dir={profile}',
            *CHROMIUM_HARDENING_FLAGS, 'about:blank']


def launch_isolated_browser():
    """Create a private profile only when launching; never touch default profiles."""
    global BROWSER, PROFILE, BROWSER_JOB, JOB_ASSIGNED
    with BROWSER_LOCK:
        if STOP.is_set():
            raise RuntimeError('보호막 세션이 종료되었습니다. 다시 실행해 주세요.')
        if BROWSER and BROWSER.poll() is None:
            return '이미 실행 중입니다.'
        paths = [
            Path(os.environ.get('PROGRAMFILES', 'C:/Program Files')) / 'Google/Chrome/Application/chrome.exe',
            Path(os.environ.get('PROGRAMFILES(X86)', 'C:/Program Files (x86)')) / 'Google/Chrome/Application/chrome.exe',
            Path(os.environ.get('LOCALAPPDATA', '')) / 'Google/Chrome/Application/chrome.exe',
            Path(os.environ.get('PROGRAMFILES(X86)', 'C:/Program Files (x86)')) / 'Microsoft/Edge/Application/msedge.exe',
            Path(os.environ.get('PROGRAMFILES', 'C:/Program Files')) / 'Microsoft/Edge/Application/msedge.exe',
        ]
        executable = next((p for p in paths if p.is_file()), None)
        if not executable:
            raise RuntimeError('Chrome 또는 Edge 실행 파일을 찾지 못했습니다.')
        if PROFILE is None:
            PROFILE = session_profile()
        try:
            BROWSER = subprocess.Popen(hardened_browser_command(executable, PROFILE))
            try:
                BROWSER_JOB = create_browser_job()
                assign_browser_job(BROWSER_JOB, BROWSER.pid)
                JOB_ASSIGNED = True
                STATE['browser_job'] = 'assigned'
            except (OSError, ctypes.WinError) as exc:
                # Job assignment is best-effort; Chromium may already belong to a job.
                close_browser_job()
                STATE['browser_job'] = 'fallback-profile-cleanup'
                log('browser', f'Windows Job Object 연결 불가, 프로필 기반 정리 유지: {exc}')
        except Exception:
            cleanup()
            raise
        log('browser', f'격리 브라우저 강화 모드 실행: {executable.name}, PID={BROWSER.pid} (확장 기능 비활성화, 시크릿 모드, 사이트 격리, V8 JIT 비활성화 요청)')
        return f'PID {BROWSER.pid}'


def cleanup():
    """Stop only Shield-profile processes; do not claim success if files remain."""
    global BROWSER, PROFILE
    with BROWSER_LOCK:
        if PROFILE is None:
            close_browser_job()
            STATE['cleanup'] = 'complete'
            return
        # Closing an assigned Job Object terminates its member processes and
        # descendants that did not explicitly break away.
        if JOB_ASSIGNED:
            close_browser_job()
        target = os.path.normcase(os.path.abspath(str(PROFILE)))
        matches = []
        for proc in psutil.process_iter(['pid', 'cmdline']):
            try:
                cmd = proc.info['cmdline'] or []
                for i, arg in enumerate(cmd):
                    value = None
                    if arg.lower().startswith('--user-data-dir='):
                        value = arg.split('=', 1)[1]
                    elif arg.lower() == '--user-data-dir' and i + 1 < len(cmd):
                        value = cmd[i + 1]
                    if value and os.path.normcase(os.path.abspath(value.strip('"'))) == target:
                        matches.append(proc)
                        break
            except (psutil.Error, OSError, ValueError):
                continue
        for proc in matches:
            try:
                proc.terminate()
            except (psutil.Error, OSError):
                pass
        _, alive = psutil.wait_procs(matches, timeout=3)
        for proc in alive:
            try:
                proc.kill()
            except (psutil.Error, OSError):
                pass
        _, alive = psutil.wait_procs(alive, timeout=2)
        # Recheck the profile after termination: Chromium may have spawned new processes.
        remaining = []
        for proc in psutil.process_iter(['pid', 'cmdline']):
            try:
                args = proc.info['cmdline'] or []
                values = [a.split('=', 1)[1] for a in args if a.lower().startswith('--user-data-dir=')]
                values += [args[i + 1] for i, a in enumerate(args[:-1]) if a.lower() == '--user-data-dir']
                if any(os.path.normcase(os.path.abspath(v.strip('\"'))) == target for v in values):
                    remaining.append(proc)
            except (psutil.Error, OSError, ValueError):
                continue
        if alive or remaining:
            STATE['cleanup'] = 'partial'
            log('error', '격리 브라우저 일부가 종료되지 않아 임시 프로필을 보존합니다.')
            return
        BROWSER = None
        try:
            shutil.rmtree(PROFILE)
            PROFILE = None
            STATE['cleanup'] = 'complete'
            log('cleanup', 'Shield 전용 임시 브라우저 프로필 삭제 완료')
        except OSError as exc:
            STATE['cleanup'] = 'partial'
            log('error', f'임시 프로필 일부 삭제 실패: {exc}')


def protect_window(hwnd):
    """Only a window owned by this process is eligible for display affinity."""
    pid = wintypes.DWORD()
    ctypes.windll.user32.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(pid))
    if pid.value != os.getpid():
        raise ValueError('다른 프로세스의 창에는 SetWindowDisplayAffinity를 적용할 수 없습니다.')
    if not ctypes.windll.user32.SetWindowDisplayAffinity(wintypes.HWND(hwnd), AFFINITY):
        raise ctypes.WinError()


def screen_guard():
    """Own-process native shield window; never claims to protect Chrome/Edge."""
    import tkinter as tk
    try:
        root = tk.Tk()
        root.title('Blackship Shield - Protected Window')
        root.geometry('470x150+120+120')
        root.configure(bg='#0c1423')
        label = tk.Label(root, text='BLACKSHIP SHIELD\n이 창은 지원되는 화면 캡처에서 제외됩니다', fg='#9ce6ec', bg='#0c1423', font=('Segoe UI', 13))
        label.pack(expand=True)
        root.update_idletasks()
        protect_window(root.winfo_id())
        STATE['screen'] = 'own-window-protected'
        log('screen', 'Shield 네이티브 창 WDA_EXCLUDEFROMCAPTURE 적용 성공')
        def poll():
            if STOP.is_set():
                root.destroy()
            else:
                root.after(300, poll)
        root.after(300, poll)
        root.mainloop()
    except Exception as exc:
        STATE['screen'] = 'unsupported'
        log('error', f'화면 캡처 제외 적용 실패: {exc}')


def auth():
    if request.headers.get('X-Shield-Token') != TOKEN:
        abort(403)
    if request.remote_addr not in ('127.0.0.1', '::1'):
        abort(403)


@app.after_request
def headers(resp):
    resp.headers['Cache-Control'] = 'no-store'
    resp.headers['X-Content-Type-Options'] = 'nosniff'
    if request.path in ('/', '/dashboard.css', '/dashboard.js'):
        resp.headers['X-Shield-Asset'] = request.path
        log('asset', f'{request.method} {request.path}: HTTP {resp.status_code}, {resp.mimetype}')
    resp.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'"
    return resp


@app.get('/')
def index():
    return send_from_directory(HERE, 'dashboard.html')


@app.get('/health/ready')
def readiness():
    """Loopback-only startup probe: verify HTML, CSS and JS on disk."""
    if request.remote_addr not in ('127.0.0.1', '::1'):
        abort(403)
    assets = ('dashboard.html', 'dashboard.css', 'dashboard.js')
    missing = [name for name in assets if not (HERE / name).is_file()]
    return jsonify(ready=not missing, missing=missing), (200 if not missing else 503)


@app.post('/api/asset-diagnostic')
def asset_diagnostic():
    auth()
    data = request.get_json(silent=True) or {}
    status = str(data.get('status', 'unknown'))[:32]
    detail = str(data.get('detail', ''))[:240]
    if status not in ('ok', 'css-failed', 'js-loaded'):
        return jsonify(ok=False, error='진단 상태가 올바르지 않습니다.'), 400
    log('asset-check' if status == 'ok' else 'asset-warning', f'{status}: {detail}')
    return jsonify(ok=True)


@app.get('/dashboard.css')
def css():
    return send_from_directory(HERE, 'dashboard.css')

@app.get('/dashboard.js')
def js():
    return send_from_directory(HERE, 'dashboard.js')


@app.get('/api/state')
def state():
    auth()
    with LOCK:
        return jsonify(state=STATE.copy(), events=EVENTS[-120:], uptime=int(time.time()-STARTED))


@app.post('/api/browser')
def browser():
    auth()
    try:
        return jsonify(ok=True, result=launch_isolated_browser())
    except Exception as exc:
        log('error', str(exc))
        return jsonify(ok=False, error=str(exc)), 400


@app.post('/api/end')
def end():
    auth()
    STOP.set()
    cleanup()
    return jsonify(ok=STATE['cleanup'] == 'complete', state=STATE.copy())


@app.post('/api/terminate')
def terminate():
    """Explicit, verified PID + creation-time confirmation; no blind registry-to-PID kill."""
    auth()
    if STOP.is_set():
        return jsonify(ok=False, error='세션이 종료되었습니다. 프로그램을 다시 실행해 주세요.'), 409
    data = request.get_json(silent=True) or {}
    try:
        pid = int(data['pid'])
        created = float(data['created'])
        proc = psutil.Process(pid)
        if abs(proc.create_time() - created) > .05:
            raise ValueError('프로세스 식별 정보가 변경되었습니다. 목록을 새로고침해 주세요.')
        if pid == os.getpid() or pid in (0, 4) or pid == os.getppid():
            raise ValueError('시스템 또는 Shield 프로세스 종료 불가')
        name = proc.name()
        # Do not terminate the running Shield browser profile through the generic process list.
        with BROWSER_LOCK:
            if PROFILE is not None:
                args = proc.cmdline()
                profile_path = os.path.normcase(os.path.abspath(str(PROFILE)))
                if any(a.lower().startswith('--user-data-dir=') and os.path.normcase(os.path.abspath(a.split('=', 1)[1].strip('\"'))) == profile_path for a in args):
                    raise ValueError('Shield 격리 브라우저는 세션 종료 기능으로 정리해 주세요.')
        proc.kill()
        STATE['blocks'] += 1
        log('blocked', f'사용자 승인 종료: {name}, PID={pid}')
        return jsonify(ok=True)
    except (KeyError, ValueError, psutil.Error, OSError) as exc:
        return jsonify(ok=False, error=str(exc)), 400


@app.get('/api/processes')
def processes():
    auth()
    if STOP.is_set():
        return jsonify(ok=False, error='세션이 종료되었습니다. 프로그램을 다시 실행해 주세요.'), 409
    items = []
    for proc in psutil.process_iter(['pid', 'name', 'create_time']):
        try:
            items.append(proc.info)
        except psutil.Error:
            continue
    return jsonify(processes=items[:800])


def shutdown():
    STOP.set()
    if PROFILE is not None and PROFILE.exists():
        cleanup()


if __name__ == '__main__':
    if os.name != 'nt':
        raise SystemExit('이 프로그램은 Windows에서만 실행할 수 있습니다.')
    atexit.register(shutdown)
    threading.Thread(target=watcher, daemon=True).start()
    threading.Thread(target=screen_guard, daemon=True).start()
    from werkzeug.serving import make_server
    server = make_server('127.0.0.1', 0, app, threaded=True)
    port = server.server_port
    print(f'Blackship Shield local dashboard: http://127.0.0.1:{port}/#token={TOKEN}')
    base_url = f'http://127.0.0.1:{port}'
    # The server must be serving requests before browser launch.
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()
    for attempt in range(40):
        try:
            with urllib.request.urlopen(base_url + '/health/ready', timeout=1) as response:
                if response.status == 200:
                    break
        except (OSError, urllib.error.URLError):
            pass
        time.sleep(0.15)
    else:
        raise RuntimeError('대시보드 리소스 준비 확인에 실패했습니다.')
    for asset, content_type in (('/', 'text/html'), ('/dashboard.css', 'text/css'), ('/dashboard.js', 'javascript')):
        with urllib.request.urlopen(base_url + asset, timeout=3) as response:
            mime = response.headers.get('Content-Type', '')
            payload = response.read()
            if response.status != 200 or content_type not in mime or not payload:
                raise RuntimeError(f'대시보드 리소스 검사 실패: {asset} ({mime})')
    print('Shield 대시보드 HTML/CSS/JS 응답 검사 완료', flush=True)
    webbrowser.open(base_url + f'/#token={TOKEN}')
    try:
        while server_thread.is_alive() and not STOP.is_set():
            server_thread.join(timeout=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
        shutdown()
