"""Process inventory and indicator matching for Blackship Shield.

Read-only assessment. Never terminate based on process names alone.
"""
from pathlib import Path
import importlib.util
import psutil

_spec = importlib.util.spec_from_file_location('blackship_shield_process_list', Path(__file__).with_name('list.py'))
_rules = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_rules)


def classify_process(name):
    basename = Path(str(name or '').replace('\\', '/')).name.casefold()
    return [key for key, names in _rules.PROCESS_INDICATORS.items() if basename in names]


def process_inventory(limit=800):
    items = []
    for proc in psutil.process_iter(['pid', 'name', 'create_time']):
        try:
            info = proc.info
            items.append({
                'pid': info['pid'],
                'name': info.get('name') or '',
                'create_time': info.get('create_time'),
                'indicators': classify_process(info.get('name')),
            })
        except (psutil.Error, OSError):
            continue
    return items[:limit]
