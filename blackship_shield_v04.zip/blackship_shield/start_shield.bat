@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 -m pip install -r requirements.txt || goto failed
  py -3 app.py
) else (
  python -m pip install -r requirements.txt || goto failed
  python app.py
)
goto end
:failed
echo Shield dependencies could not be installed. Please check Python and your network connection.
pause
:end
