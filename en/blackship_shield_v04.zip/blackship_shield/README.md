# Blackship Shield — shield/ 폴더 배치

프로젝트 루트에는 `blackship.py`만 놓고, 아래 파일은 전부 `shield/` 안에 둡니다.

```
Blackship/
├── blackship.py
└── shield/
    ├── __init__.py
    ├── app.py
    ├── dashboard.html
    ├── dashboard.js
    ├── requirements.txt
    ├── start_shield.bat
    └── README.md
```

**중요:** 프로젝트 루트에 이전 버전의 `shield.py`가 남아 있다면 제거하거나 백업 위치로 옮기세요. `from shield import build_shield_page`가 이제 `shield/__init__.py`를 불러옵니다.

최신 blackship.py의 `from shield import build_shield_page` 및 기존 세 곳의 호출은 수정하지 않았습니다.

`python blackship.py --no-fetch` 또는 기존 빌드를 실행하면 `_transfer/shield.html`, `_transfer/en/shield.html` 및 각 언어 폴더의 `blackship_shield_v04.zip`이 생성됩니다. 사이트 방문자는 ZIP을 받아 Windows에서 압축 해제 후 `start_shield.bat`을 실행합니다.

주의: 실제 Windows 보안 기능은 이 환경에서 실기 검증하지 않았습니다. 화면 캡처 제외는 Shield 자체 창에만 적용되고, 키로거 탐지·임의 브라우저 보호·자동 PID 식별 및 차단은 구현되지 않았습니다.
