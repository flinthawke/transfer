'use strict';
const token = new URLSearchParams(location.hash.slice(1)).get('token') || sessionStorage.getItem('blackshipShieldToken');
if (token) { sessionStorage.setItem('blackshipShieldToken', token); history.replaceState(null,'',location.pathname); }
const el=id=>document.getElementById(id);
const req=async(path,method='GET',body)=>{
 const res=await fetch(path,{method,headers:{'X-Shield-Token':token,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,cache:'no-store'});
 const data=await res.json().catch(()=>({})); if(!res.ok)throw Error(data.error||`요청을 처리하지 못했습니다. (HTTP ${res.status})`);return data;
};
function cell(row,value){const td=document.createElement('td');td.textContent=String(value);row.append(td);return td;}
function renderLogs(events){const body=el('events');body.replaceChildren();for(const e of [...events].reverse()){
 const row=document.createElement('tr');cell(row,e.at);cell(row,e.kind);cell(row,e.detail);body.append(row);
}}
async function poll(){try{const d=await req('/api/state');el('connected').textContent='로컬 엔진 연결됨';el('camera').textContent=d.state.camera;el('screen').textContent=d.state.screen;el('blocks').textContent=d.state.blocks;
 const t=d.uptime;el('uptime').textContent=[Math.floor(t/3600),Math.floor(t/60)%60,t%60].map(x=>String(x).padStart(2,'0')).join(':');renderLogs(d.events);
}catch(e){el('connected').textContent='엔진 연결 끊김';}}
let listedProcesses=[];
async function refresh(){try{const d=await req('/api/processes');const body=el('processes');body.replaceChildren();listedProcesses=d.processes;for(const p of d.processes){const tr=document.createElement('tr');const choose=document.createElement('td');const check=document.createElement('input');check.type='checkbox';check.className='process-select';check.dataset.pid=p.pid;check.disabled=!!p.protected;choose.append(check);tr.append(choose);cell(tr,p.pid);cell(tr,p.name||'?');cell(tr,(p.reasons||[]).join(' ')||'자동 검토 근거 없음');const td=document.createElement('td');const b=document.createElement('button');b.textContent='종료';b.className='danger';b.onclick=async()=>{if(!confirm(`${p.name} (PID ${p.pid}) 프로세스를 강제 종료하시겠습니까?`))return;try{await req('/api/terminate','POST',{pid:p.pid,created:p.create_time});el('message').textContent=`PID ${p.pid} 종료 요청이 완료되었습니다.`;refresh();}catch(e){el('message').textContent=e.message;}};td.append(b);tr.append(td);body.append(tr);}}catch(e){el('message').textContent=e.message;}}
el('refresh').onclick=refresh;
el('launch').onclick=async()=>{try{const d=await req('/api/browser','POST');el('message').textContent=`격리 브라우저: ${d.result}`;}catch(e){el('message').textContent=e.message;}};
el('end').onclick=async()=>{if(!confirm('격리 브라우저를 닫고 Shield 전용 임시 프로필을 삭제하시겠습니까?'))return;try{const d=await req('/api/end','POST');el('message').textContent=`세션 종료 요청이 완료되었습니다. 임시 프로필 정리 상태: ${d.state.cleanup}`;sessionStorage.removeItem('blackshipShieldToken');el('launch').disabled=true;el('end').disabled=true;el('refresh').disabled=true;document.querySelectorAll('#processes button').forEach(b=>b.disabled=true);poll();}catch(e){el('message').textContent=e.message;}};
poll();refresh();setInterval(poll,1000);

// Browser-side rendering probe; failures are recorded without interrupting the dashboard.
window.addEventListener('load', async () => {
  try {
    const stylesheet = document.querySelector('link[href*="dashboard.css"]');
    const sheetLoaded = !!stylesheet && [...document.styleSheets].some(sheet =>
      sheet.href && new URL(sheet.href).pathname === '/dashboard.css');
    const css = getComputedStyle(document.body);
    const status = sheetLoaded ? 'ok' : 'css-failed';
    await req('/api/asset-diagnostic', 'POST', {
      status,
      detail: `stylesheet=${sheetLoaded}; background=${css.backgroundColor}; ready=${document.readyState}`
    });
  } catch (error) {
    console.warn('Shield 스타일 진단을 기록하지 못했습니다.', error);
  }
});

el('select-suspects').onclick=()=>{document.querySelectorAll('.process-select').forEach(c=>{const p=listedProcesses.find(x=>String(x.pid)===c.dataset.pid);c.checked=!!p?.review&&!c.disabled;});};
el('terminate-selected').onclick=async()=>{const ids=[...document.querySelectorAll('.process-select:checked')].map(c=>Number(c.dataset.pid));const items=listedProcesses.filter(p=>ids.includes(p.pid)).map(p=>({pid:p.pid,created:p.create_time}));if(!items.length){el('message').textContent='종료할 프로세스를 선택해 주세요.';return;}if(!confirm(`선택한 ${items.length}개 프로세스의 정상 종료를 요청하시겠습니까? 저장되지 않은 데이터가 손실될 수 있습니다.`))return;try{const d=await req('/api/terminate-batch','POST',{items});el('message').textContent=d.results.map(x=>`PID ${x.pid}: ${x.ok?'종료 완료':x.error}`).join(' / ');await refresh();}catch(e){el('message').textContent=e.message;}};
async function runCleanup(all){const boxes=[...document.querySelectorAll('.cleanup-item')];if(all)boxes.forEach(b=>b.checked=true);const items=boxes.filter(b=>b.checked).map(b=>b.value);if(!items.length){el('cleanup-result').textContent='정리 항목을 선택해 주세요.';return;}if(!confirm(`${items.length}개 정리 항목을 실행하시겠습니까?`))return;try{const d=await req('/api/cleanup-selected','POST',{items});el('cleanup-result').textContent=Object.entries(d.results).map(([k,v])=>`${k}: ${v.ok?'완료':'실패'} ${v.detail||''}`).join(' / ');}catch(e){el('cleanup-result').textContent=e.message;}}
el('cleanup-selected').onclick=()=>runCleanup(false);
el('cleanup-all').onclick=()=>runCleanup(true);
